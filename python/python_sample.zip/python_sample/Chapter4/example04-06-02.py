# coding:utf-8a = "abc"def test():    print(a)    returntest()print(a)
