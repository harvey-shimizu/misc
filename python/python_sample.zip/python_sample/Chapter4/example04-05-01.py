# coding:utf-8for a in range(1, 10+1):    if a <= 5:      print("小さいです")    else:      print("大きいです")
