# coding:utf-8total = 0a = 1while total <= 50:    total = total + a    a = a + 1print(total)
