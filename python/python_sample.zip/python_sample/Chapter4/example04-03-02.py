# coding:utf-8for a in "Hello":    print(a)
