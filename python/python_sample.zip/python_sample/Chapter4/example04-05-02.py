# coding:utf-8for a in range(1, 10 + 1):    print(a)    if a % 2 == 0:        print("○")    if a % 3 == 0:        print("×")    if (a % 2 == 0) and (a % 3 == 0):        print("△")
