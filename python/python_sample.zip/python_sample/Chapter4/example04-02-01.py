# coding:utf-8a = 1b = 2print(a + b)
