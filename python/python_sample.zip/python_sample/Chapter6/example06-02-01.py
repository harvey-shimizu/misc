# coding:utf-8import tkinter as tkroot = tk.Tk()root.mainloop()
