import tkinter as tkfor f in tk.Tk().call("font","families"):    print(f)
