# coding:utf-8import tkinter as tkroot = tk.Tk()root.geometry("400x150")root.title("数当てゲーム")root.mainloop()
