print("abc"+"cde"+"def"+"hig")
