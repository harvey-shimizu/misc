# coding:utf-8print("こんにちは。今日の晩ご飯は何でしたか？", end="")print("おいしかったですか？", end="")print("何カロリーでしたか？")
