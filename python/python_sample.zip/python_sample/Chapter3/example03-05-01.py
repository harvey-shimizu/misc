print("abc"+"cde")
