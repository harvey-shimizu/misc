print(1+2)print(3+4)print(4+5)
