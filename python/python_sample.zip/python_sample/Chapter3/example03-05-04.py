print("abc"+str(123*234))
