print("こんにちは")
