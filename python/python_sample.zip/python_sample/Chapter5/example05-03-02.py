# coding:utf-8import randoma = [random.randint(0, 9),     random.randint(0, 9),     random.randint(0, 9),     random.randint(0, 9)]print(str(a[0]) + str(a[1]) + str(a[2]) + str(a[3]))
