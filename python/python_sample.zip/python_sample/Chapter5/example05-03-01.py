# coding:utf-8import randoma1 = random.randint(0, 9)a2 = random.randint(0, 9)a3 = random.randint(0, 9)a4 = random.randint(0, 9)print(str(a1) + str(a2) + str(a3) + str(a4))
