# coding:utf-8b = input("数を入れてね>")print(b)
