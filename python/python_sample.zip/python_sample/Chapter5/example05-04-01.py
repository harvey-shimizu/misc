# coding:utf-8import randomb = input("数を入れてね>")print(b[0])print(b[1])print(b[2])print(b[3])
